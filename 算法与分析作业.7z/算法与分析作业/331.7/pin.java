import java.util.*;
 
public class pin{
	static int n;
	static int[] a;  
	static boolean[] b;  
	
	static void dfs(int step){   
		if(step==n+1){   
			for(int i=1;i<=n;i++)
				System.out.print(a[i]);
			System.out.println();
            return;
		}
		for(int i=1;i<=n;i++){	
			if(!b[i]){    
				a[step]=i;     
				b[i]=true;   
				dfs(step+1);    
				b[i]=false;   
			}
		}
		
	}
	public static void main(String[] args){
		Scanner in=new Scanner(System.in);
		n=in.nextInt();
		a=new int[n+1];
		b=new boolean[n+1];
		dfs(1);   
	}
}
